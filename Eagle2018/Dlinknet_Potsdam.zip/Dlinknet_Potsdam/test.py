from util import *
import torch
import torch.nn as nn
import torch.utils.data as data
from torch.autograd import Variable as V
import scipy.misc as misc
import cv2
import os
import numpy as np
import pickle
#import pydensecrf.densecrf as dcrf
from time import time
import torchvision.transforms as transforms
from networks.unet import Unet
from networks.dunet import Dunet
from networks.dinknet import LinkNet34, DinkNet34, DinkNet50, DinkNet101, DinkNet34_less_pool, MyDinkNet34
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
BATCHSIZE_PER_CARD = 1
mode = 1 #default ge4, potsdam == 1
normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225])
trans = transforms.Compose([
            transforms.ToTensor(),
            normalize,
        ])

class TTAFrame():
    def __init__(self, net):
        self.net = net().cuda()
        self.net = torch.nn.DataParallel(self.net, device_ids=range(torch.cuda.device_count()))

    def test_one_img_from_path(self, path, evalmode=True):
        if evalmode:
            self.net.eval()
        batchsize = torch.cuda.device_count() * BATCHSIZE_PER_CARD
        if batchsize >= 8:
            return self.test_one_img_from_path_1(path)
        elif batchsize >= 4:
            return self.test_one_img_from_path_2(path)
        elif batchsize >= 2:
            return self.test_one_img_from_path_0(path)
        else:
            return self.test_one_img_from_path_0(path)

    def test_one_img_from_path_0(self, path, evalmode=True):
       # print(patih)
        img = cv2.imread(path)
        (b, g, r) = cv2.split(img)
        img = cv2.merge([r, g, b])
        img1 = trans(img)
        img1 = torch.unsqueeze(img1, dim=0)
        tic = time()
        mask = self.net.forward(img1.cuda()).squeeze().cpu().data.numpy()
        mask1 = torch.max(torch.from_numpy(mask.transpose(2, 1, 0)), 2)[1].numpy()
        print (i / 10, '    ', '%.8f' % (time() - tic) )
        return mask1, mask

    def test_one_img_from_path_8(self, path):
        img = cv2.imread(path)  # .transpose(2,0,1)[None]
        img90 = np.array(np.rot90(img))
        img1 = np.concatenate([img[None], img90[None]])
        img2 = np.array(img1)[:, ::-1]
        img3 = np.array(img1)[:, :, ::-1]
        img4 = np.array(img2)[:, :, ::-1]

        img1 = img1.transpose(0, 3, 1, 2)
        img2 = img2.transpose(0, 3, 1, 2)
        img3 = img3.transpose(0, 3, 1, 2)
        img4 = img4.transpose(0, 3, 1, 2)

        img1 = V(torch.Tensor(np.array(img1, np.float32) / 255.0 * 3.2 - 1.6).cuda())
        img2 = V(torch.Tensor(np.array(img2, np.float32) / 255.0 * 3.2 - 1.6).cuda())
        img3 = V(torch.Tensor(np.array(img3, np.float32) / 255.0 * 3.2 - 1.6).cuda())
        img4 = V(torch.Tensor(np.array(img4, np.float32) / 255.0 * 3.2 - 1.6).cuda())

        maska = self.net.forward(img1).squeeze().cpu().data.numpy()
        maskb = self.net.forward(img2).squeeze().cpu().data.numpy()
        maskc = self.net.forward(img3).squeeze().cpu().data.numpy()
        maskd = self.net.forward(img4).squeeze().cpu().data.numpy()

        mask1 = maska + maskb[:, ::-1] + maskc[:, :, ::-1] + maskd[:, ::-1, ::-1]
        mask2 = mask1[0] + np.rot90(mask1[1])[::-1, ::-1]

        return mask2

    def test_one_img_from_path_4(self, path):
        img = cv2.imread(path)  # .transpose(2,0,1)[None]
        img90 = np.array(np.rot90(img))
        img1 = np.concatenate([img[None], img90[None]])
        img2 = np.array(img1)[:, ::-1]
        img3 = np.array(img1)[:, :, ::-1]
        img4 = np.array(img2)[:, :, ::-1]

        img1 = img1.transpose(0, 3, 1, 2)
        img2 = img2.transpose(0, 3, 1, 2)
        img3 = img3.transpose(0, 3, 1, 2)
        img4 = img4.transpose(0, 3, 1, 2)

        img1 = V(torch.Tensor(np.array(img1, np.float32) / 255.0 * 3.2 - 1.6).cuda())
        img2 = V(torch.Tensor(np.array(img2, np.float32) / 255.0 * 3.2 - 1.6).cuda())
        img3 = V(torch.Tensor(np.array(img3, np.float32) / 255.0 * 3.2 - 1.6).cuda())
        img4 = V(torch.Tensor(np.array(img4, np.float32) / 255.0 * 3.2 - 1.6).cuda())

        maska = self.net.forward(img1).squeeze().cpu().data.numpy()
        maskb = self.net.forward(img2).squeeze().cpu().data.numpy()
        maskc = self.net.forward(img3).squeeze().cpu().data.numpy()
        maskd = self.net.forward(img4).squeeze().cpu().data.numpy()

        mask1 = maska + maskb[:, ::-1] + maskc[:, :, ::-1] + maskd[:, ::-1, ::-1]
        print(mask1.shape)
        mask2 = mask1[0] + np.rot90(mask1[1])[::-1, ::-1]


        return mask2

    def test_one_img_from_path_2(self, path):
        img = cv2.imread(path)  # .transpose(2,0,1)[None]
        img90 = np.array(np.rot90(img))
        img1 = np.concatenate([img[None], img90[None]])
        img2 = np.array(img1)[:, ::-1]
        img3 = np.concatenate([img1, img2])
        img4 = np.array(img3)[:, :, ::-1]
        img5 = img3.transpose(0, 3, 1, 2)
        img5 = np.array(img5, np.float32) / 255.0 * 3.2 - 1.6
        img5 = V(torch.Tensor(img5).cuda())
        img6 = img4.transpose(0, 3, 1, 2)
        img6 = np.array(img6, np.float32) / 255.0 * 3.2 - 1.6
        img6 = V(torch.Tensor(img6).cuda())

        maska = self.net.forward(img5).squeeze().cpu().data.numpy()  # .squeeze(1)
        maskb = self.net.forward(img6).squeeze().cpu().data.numpy()

        mask1 = maska + maskb[:, :, ::-1]
        mask2 = mask1[:2] + mask1[2:, ::-1]
        mask3 = mask2[0] + np.rot90(mask2[1])[::-1, ::-1]

        return mask3

    def test_one_img_from_path_1(self, path):
        img = cv2.imread(path)  # .transpose(2,0,1)[None]

        img90 = np.array(np.rot90(img))
        img1 = np.concatenate([img[None], img90[None]])
        img2 = np.array(img1)[:, ::-1]
        img3 = np.concatenate([img1, img2])
        img4 = np.array(img3)[:, :, ::-1]
        img5 = np.concatenate([img3, img4]).transpose(0, 3, 1, 2)
        img5 = np.array(img5, np.float32) / 255.0 * 3.2 - 1.6
        img5 = V(torch.Tensor(img5).cuda())

        mask = self.net.forward(img5).squeeze().cpu().data.numpy()  # .squeeze(1)
        mask1 = mask[:4] + mask[4:, :, ::-1]
        mask2 = mask1[:2] + mask1[2:, ::-1]
        mask3 = mask2[0] + np.rot90(mask2[1])[::-1, ::-1]

        return mask3

    def load(self, path):
        self.net.load_state_dict(torch.load(path))


def label2annotation(pic):
    # input:  8 bits picture
    # output: 24 bits picture

    new_pic = np.zeros([512, 512, 3])
    if mode == 0:
        for i in range(pic.shape[0]):
            for j in range(pic.shape[1]):
                if pic[i][j] == 0:
                    new_pic[i][j][0] = 30
                    new_pic[i][j][1] = 100
                    new_pic[i][j][2] = 30

                elif pic[i][j] == 1:
                    new_pic[i][j][0] = 200
                    new_pic[i][j][1] = 200
                    new_pic[i][j][2] = 200

                elif pic[i][j] == 2:
                    new_pic[i][j][0] = 0
                    new_pic[i][j][1] = 255
                    new_pic[i][j][2] = 0

                elif pic[i][j] == 3:
                    new_pic[i][j][0] = 0
                    new_pic[i][j][1] = 0
                    new_pic[i][j][2] = 255

                else:
                    new_pic[i][j][0] = 0
                    new_pic[i][j][1] = 0
                    new_pic[i][j][2] = 0
        return new_pic.astype(np.uint8)
    elif mode == 1:
        for i in range(pic.shape[0]):
            for j in range(pic.shape[1]):
                if pic[i][j] == 0:
                    new_pic[i][j][0] = 255
                    new_pic[i][j][1] = 255
                    new_pic[i][j][2] = 255

                elif pic[i][j] == 1:
                    new_pic[i][j][0] = 0
                    new_pic[i][j][1] = 0
                    new_pic[i][j][2] = 255

                elif pic[i][j] == 2:
                    new_pic[i][j][0] = 0
                    new_pic[i][j][1] = 255
                    new_pic[i][j][2] = 255
                elif pic[i][j] == 3:
                    new_pic[i][j][0] = 0
                    new_pic[i][j][1] = 255
                    new_pic[i][j][2] = 0

                elif pic[i][j] == 4:
                    new_pic[i][j][0] = 255
                    new_pic[i][j][1] = 255
                    new_pic[i][j][2] = 0

                elif pic[i][j] == 5:
                    new_pic[i][j][0] = 255
                    new_pic[i][j][1] = 0
                    new_pic[i][j][2] = 0
        return new_pic.astype(np.uint8)


# source = 'dataset/test/'
target_dir = '/server_space/jiangyl/zhu_useful/Potsdam_512_full/test/gt/'
source = '/server_space/jiangyl/zhu_useful/Potsdam_512_full/test/img/'
val = os.listdir(source)
solver = TTAFrame(DinkNet50)
solver.load('weights/dlinknet50_final95.th')
target = 'submits/addval/'
oas = 0
cms = np.zeros([6,6])
timetime = time()
for i, name in enumerate(val):
    mask, raw = solver.test_one_img_from_path(source + name)
    print(mask.shape)
    gt = np.load(os.path.join(target_dir,name[:-3]+'npy'))   
# d = dcrf.DenseCRF2D(512, 512, 6)
   # U = -np.log(raw)
   # U = U.reshape((6,-1))
   # d.addPairwiseGaussian(sxy=3, compat=3)
   # d.setUnaryEnergy(U)
   # Q = d.inference(20)
  #  print(raw.shape)
    gt = np.transpose(gt,(1,2,0))
    print('gt',gt.shape)
    print('mask',mask.transpose(1,0).shape)
    oa,cm = calculate_metrics(mask.transpose(1,0),gt,6)
 #   oas = oa+oas   
 #   cms = cm + cms
# map = np.argmax(Q, axis=0).reshape((512,512))
   # img = torch.max(torch.from_numpy(mask.transpose(2, 1, 0)), 2)[1].numpy()
    img = label2annotation(mask)
    img = np.transpose(img,(1,0,2)) 
    #np.save('output/1/'+name[:-4], raw)
    misc.imsave('output/help/'+name[:-3]+'bmp', img)
#kappa = conf_mat2_kappa(cms)
#result = open(os.path.join(target,'dlinknet9_5.txt'),'w')
#print >> result, 'OA:', oas/len(val)
#print >> result, 'confusion_matrix:', cms
#print >> result, 'kappa:',kappa
#result.close()
print('Finish!!')
print(time()-timetime)
