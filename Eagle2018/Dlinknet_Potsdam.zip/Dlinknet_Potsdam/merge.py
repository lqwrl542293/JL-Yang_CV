import numpy as np
import cv2
import os
import scipy.misc

FOLDER = '/server_space/jiangyl/dlink_potsdam_normto1/output/3/'
SAVE_FOLDER = '/server_space/jiangyl/dlink_potsdam_normto1/output/3/'
TARGET_TYPE = '.bmp'

row_1 = 0
col_1 = 0
row_2 = 512
col_2 = 0
row_3 = 1024
col_3 = 0
row_4 = 1536
col_4 = 0
count = 0
row_5 = 2048
col_5 = 0
row_6 = 2560
col_6 = 0
row_7 = 3072
col_7 = 0
row_8 = 3584
col_8 = 0
row_9 = 4096
col_9 = 0
row_10 = 4608
col_10 = 0
row_11 = 5120
col_11 = 0
row_12 = 5488
col_12 = 0
judge = 0
merge = np.zeros((6000,6000,3))
while judge != 1:
	print(count)
        print(os.path.join(FOLDER,'top_potsdam_2_13_rgb-'+str(count)+'.bmp'))
	img = cv2.imread(os.path.join(FOLDER,'top_potsdam_2_13_rgb-'+str(count)+'.bmp'),1)
	(b, g, r) = cv2.split(img)
	img = cv2.merge([r, g, b])
	#img = np.transpose(img,(1,0,2))
	if count < 12:
		merge[row_1:row_1+512,col_1 : col_1 +512] = img
		col_1 = col_1 +512
		if col_1 == 5632:
			col_1 = 5488
		

	if count >= 12 and count < 24:

		merge[row_2:row_2+512,col_2 : col_2 +512] = img
		col_2 = col_2 +512
		if col_2 == 5632:
			col_2 = 5488	

	if count >= 24 and count < 36:
		merge[row_3:row_3+512,col_3 : col_3 +512] = img
		col_3 = col_3 +512
		if col_3 == 5632:
			col_3 = 5488

	if count >= 36 and count < 48:
		merge[row_4:row_4+512 ,col_4 : col_4 +512] = img
		col_4 = col_4 + 512
		
		if col_4 == 5632:
			col_4 = 5488

	if count >= 48 and count < 60:
		merge[row_5:row_5+512,col_5: col_5 +512] = img
		col_5 = col_5 + 512
		if col_5 == 5632:
			col_5 = 5488

	if count >= 60 and count < 72:
		merge[row_6:row_6+512,col_6 : col_6 +512] = img
		col_6 = col_6 + 512		
		if col_6 == 5632:
			col_6 = 5488

	if count >= 72 and count < 84:
		merge[row_7:row_7+512,col_7 : col_7 +512] = img
		col_7 = col_7 + 512		
	
		if col_7 == 5632:
			col_7 = 5488

	if count >= 84 and count < 96:
		merge[row_8:row_8+512 , col_8 : col_8 +512] = img
		col_8 = col_8 + 512		

		if col_8 == 5632:
			col_8 = 5488

	if count >= 96 and count < 108:
		merge[row_9:row_9+512 , col_9 : col_9 +512] = img
		col_9 = col_9 + 512		
		if col_9 == 5632:
			col_9 = 5488

	if count >= 108 and count < 120:
		merge[row_10:row_10+512 , col_10 : col_10 +512] = img
		col_10 = col_10 + 512		
		if col_10 == 5632:
			col_10 = 5488

	if count >= 120 and count < 132:
		merge[row_11:row_11+512 , col_11: col_11 +512] = img
		col_11 = col_11 + 512		
		if col_11 == 5632:
			col_11 = 5488


	if count >= 132 and count < 144:
		merge[row_12:row_12+512 , col_12 : col_12 +512] = img
		col_12 = col_12 + 512	
		if col_12 == 5632:
			col_12 = 5488
		if col_12 == 6000:
			judge = 1	
	count += 1
	

print('home')
print(merge)


scipy.misc.imsave(SAVE_FOLDER+'1k.bmp',merge)
