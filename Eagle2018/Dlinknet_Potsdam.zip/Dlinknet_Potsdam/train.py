import torch
import torch.utils.data as data
import torch.nn as nn
import os
import torchvision.transforms as transforms
from time import time
from networks.dinknet import LinkNet34, DinkNet34, DinkNet50, DinkNet101, DinkNet34_less_pool, MyDinkNet34
from framework import MyFrame
from loss import dice_bce_loss
from data import ImageFolder

LEARNING_RATE = 2e-4
SHAPE = (512, 512)
ROOT = '/server_space/jiangyl/Potsdam_512_full/train/'
VROOT = '/server_space/jiangyl/Potsdam_512_full/val/'
vimagelist = os.listdir(VROOT+'img/')
validlist = map(lambda x: x[:-4], vimagelist)
imagelist = os.listdir(ROOT+'img/')
trainlist = map(lambda x: x[:-4], imagelist)
NAME = 'dlinknet50_final'
BATCHSIZE_PER_CARD = 2

solver = MyFrame(DinkNet50, dice_bce_loss, LEARNING_RATE)
batchsize = torch.cuda.device_count() * BATCHSIZE_PER_CARD
normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225])
trans = transforms.Compose([
            transforms.ToTensor(),
            normalize,
        ])
validset = ImageFolder(validlist,VROOT)

valid_loader = torch.utils.data.DataLoader(
    validset,
    batch_size=batchsize,
    shuffle=True,
    num_workers=10)

dataset = ImageFolder(trainlist, ROOT)
torch.cuda.empty_cache()
data_loader = torch.utils.data.DataLoader(
    dataset,
    batch_size=batchsize,
    shuffle=True,
    num_workers=10)

mylog = open('logs/' + NAME + '.log', 'w')
tic = time()
no_optim = 0
total_epoch = 600
train_epoch_best_loss = 100.
#valid_epoch_best_loss = 100.
#solver.load('./weights/log_potsda_full_compare.th')
for epoch in range(1, total_epoch + 1):
    data_loader_iter = iter(data_loader)
#    valid_loader_iter = iter(valid_loader)
    train_epoch_loss = 0
#    valid_epoch_loss = 0
    for img, mask in data_loader_iter:
        solver.set_input(img, mask)
        train_loss = solver.optimize()
        train_epoch_loss += train_loss
#    torch.cuda.empty_cache()
#    valid_loader_iter = iter(valid_loader) 
#    for img,mask in valid_loader_iter:
#        solver.set_valinput(img, mask)
#        val_loss = solver.val()
#        valid_epoch_loss += val_loss
    train_epoch_loss /= len(data_loader_iter)
#    valid_epoch_loss /= len(valid_loader_iter)

    print >> mylog, '********'
    print >> mylog, 'epoch:',epoch,'    time:',int(time()-tic)
    print >> mylog, 'train_loss:',train_epoch_loss
#    print >> mylog, 'validation_loss:',valid_epoch_loss
    print >> mylog, 'SHAPE:',SHAPE
    print >> mylog, 'learning_rate:',solver.old_lr
    print '********'
    print 'epoch:',epoch,'    time:',int(time()-tic)
    print 'train_loss:',train_epoch_loss
   # print 'validation_loss', valid_epoch_loss
    print 'SHAPE:',SHAPE
    if train_epoch_loss >0 and train_epoch_loss<=50:
        if epoch %10 == 0:
            solver.save('weights/' + NAME +str(epoch)+ '.th')
    if epoch > 50 and epoch<= 150:
        if epoch %5 == 0:
            solver.save('weights/' + NAME +str(epoch)+ '.th')
    if epoch > 150 and epoch <= 300:
        if epoch % 3 == 0:
            solver.save('weights/' + NAME +str(epoch)+ '.th')

    if epoch > 300 and epoch <= 600:
        if epoch % 2 == 0:
            solver.save('weights/' + NAME +str(epoch)+ '.th')
    if train_epoch_loss >= train_epoch_best_loss:
        no_optim += 1
    else:
        no_optim = 0
        train_epoch_best_loss = train_epoch_loss
        solver.save('weights/' + NAME + '.th')
    if no_optim > 6:
        print('early stop at %d epoch' % epoch)
        break
    if no_optim > 3:
        if solver.old_lr < 1e-12:
            break
        solver.load('weights/' + NAME + '.th')
        solver.update_lr(5.0, factor=True, mylog=mylog)
    mylog.flush()

print >> mylog, 'Finish!'
print('Finish!')
mylog.close()
