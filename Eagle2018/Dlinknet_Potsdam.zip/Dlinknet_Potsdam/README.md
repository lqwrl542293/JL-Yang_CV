# Dlinknet_Potsdam

```bash
python train.py; Begin Training
python test.py; Begin Testing
```

`data.py:` dataloader

`utili.py:`accuracy calculation

`loss.py:`loss function of dlinknet. (Dice loss + BCE)

`networks/dinknet.py:` neural network architecture of Dlinknet. ( num of class need to be modify to adapt different segmentation tasks.)

`merge.py:` After testing the model, it can merge 144 512x512 output pics into one 6000x6000 pic. The name of divided pics need to be named in order. Name format : *xxxxx-order[0,144).bmp*, example *Potsdam_2_13-107.bmp*. 

Label maps are converted by `convert_file.py`.

